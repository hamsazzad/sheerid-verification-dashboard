"""ChatGPT 军人 SheerID 认证模块"""

