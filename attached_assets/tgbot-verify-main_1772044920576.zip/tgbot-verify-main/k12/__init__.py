"""ChatGPT Teacher K12 SheerID 认证模块"""
