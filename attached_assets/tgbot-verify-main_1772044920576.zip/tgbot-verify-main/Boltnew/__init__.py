"""Bolt.new Teacher SheerID 认证模块"""
